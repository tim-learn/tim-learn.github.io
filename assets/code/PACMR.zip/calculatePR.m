function PRresult = calculatePR( queryset, test_Y,Dist )

    %%%%%%%
    Precision = [];
    Recall = [];
    gap = 0.025;
    
    numofclass = size(unique(test_Y),1);
    Numofrelevant = zeros(1, numofclass);
    for i=1: numofclass
        index = find(test_Y == i);
        Numofrelevant(i) = length(index);
    end
    
    %Dist = EuDist2(queryset, targetset);
    %Dist = CosineDist(queryset, targetset);
    [~,index] = sort(Dist, 2, 'ascend');
    classIndex = test_Y(index);
    
    %AP = [];
    
    [num c] = size( queryset );
    for k = 1:num
        reClassIndex = find(classIndex(k, :) == test_Y(k));
        relength = length(reClassIndex);
        counts = [1:relength];
        precision = counts./reClassIndex;
        recall = counts/Numofrelevant(test_Y(k));
        
        precisionOfGap = zeros(1, 1/gap);
        ind = 0;
        for j = gap:gap:1
            ind = ind + 1;
            gapInd = find(recall>j-gap & recall<=j);
            if ~isempty(gapInd) 
                precisionOfGap(ind) = max(precision(gapInd));
            end
        end
        Precision = [Precision; precisionOfGap];
        %AP =[AP sum(counts./reClassIndex)/relength];
    end
    
    Precision = mean(Precision);
    Recall = 0:gap:1;
    ZeroInd = find(Precision == 0);
    Precision(Precision == 0) = [];
    Recall(ZeroInd) = [];
    Precision = [Precision 2*Precision(1, end)-Precision(1, end-1)];
    
    PRresult = zeros(size(Recall, 2),2);
    PRresult(:,1) = Recall;
    PRresult(:,2) = Precision;
    
    
end