addpath('./liblinear/matlab/')

filename = 'voc.mat';
disp ('loading...')
load(filename);

[~,cI] = litekmeans(I_tr,200,'Replicates',3);
[~,cT] = litekmeans(T_tr,200,'Replicates',3);

% [~,cIT] = litekmeans([I_tr,T_tr],200,'Replicates',3);
% cI = cIT(:,1:size(I_tr,2));
% cT = cIT(:,1+size(I_tr,2):end);

di = sqdist(I_tr,cI);
sigmaI2 = mean(sqrt(di(:))).^2;

di = sqdist(T_tr,cT);
sigmaT2 = mean(sqrt(di(:))).^2;
% Isim = exp(-di/sigma);
I_tr = exp(-sqdist(I_tr,cI)/sigmaI2);
T_tr = exp(-sqdist(T_tr,cT)/sigmaT2);
I_te = exp(-sqdist(I_te,cI)/sigmaI2);
T_te = exp(-sqdist(T_te,cT)/sigmaT2);

%%
C = 100;
tic;model_I = train(trY, sparse(I_tr),sprintf('-s 0 -B 1 -c %1.8f -q', C));toc
[~, ~, PI_te] = predict(teY, sparse(I_te), model_I,' -b 1 -q');
tic;model_T = train(trY, sparse(T_tr),sprintf('-s 0 -B 1 -c %1.8f -q', C));toc
[~, ~, PT_te] = predict(teY, sparse(T_te), model_T,' -b 1 -q');

[~, ~, PI_tr] = predict(trY, sparse(I_tr), model_I,' -b 1'); 
[~, ~, PT_tr] = predict(trY, sparse(T_tr), model_T,' -b 1'); 


% mapI = evaluate(PI_te,PT_te,teY,'cosine');
% mapT = evaluate(PT_te,PI_te,teY,'cosine');
mapI = evaluate(PI_te,PT_te,teY,'ip');
mapT = evaluate(PT_te,PI_te,teY,'ip');
fprintf('mapI:%.4f,mapT:%.4f,average map:%.4f...\n',mapI,mapT,(mapI+mapT)/2);

