function [A,output] = ours_aaai_simple7(options) 
    Xs = options.xs;
    Xt = options.xt;
    Ys = options.ys;
    Yt = options.yt;
    if ~isfield(options,'init')
        options.init = 0;
    end
    if ~isfield(options,'test')
        options.test = 0;
    end
    
    if ~isfield(options,'distance')
        options.distance = 'euclidean';
    end
  
    if ~isfield(options,'alpha')
        options.alpha = 2;
    end
    alpha = options.alpha;
    
    addpath('../src/liblinear-2.1/matlab')
    ns = size(Xs,2);
    nt = size(Xt,2);
    k = length(unique(Ys));

    Cls = [];   
    Xs = normc(Xs);
    Xt = normc(Xt); 
    if true     
        Xs = Xs - repmat(mean(Xs,2),1,size(Xs,2));
        Xt = Xt - repmat(mean(Xt,2),1,size(Xt,2));
        m = size(Xs,1);
    end 
    if options.test
        cls = knnclassify(Xt',Xs', Ys, 1, options.distance);
        output.iacc = length(find(cls==Yt))/length(Yt);
        A = 0;
        return;
    end

    X = [Xs, Xt];
    n = ns + nt;
    
    if options.init
        if isfield(options,'py')
            cls = options.py;
        else
            tp = full(sparse(1:ns,Ys,1));
            nys = tp*diag(1./sum(tp));
            cls = knnclassify(Xt',nys'*Xs',1:k,1,options.distance); 
        end
    else
        cls = [];   
    end   

    % solve A
    T = Xs*Xs' + Xt*Xt';
    T = T + eps*speye(m);

    tp = full(sparse(1:ns,Ys,1));
    nys = tp*diag(1./sum(tp));
    lu = Xs - Xs*nys*tp';
    lu = lu*lu';

    [A,~] = eigs(lu+options.lambda*speye(m), T, options.k, 'sm');  
    output.iacc= [];
    output.obj = [];
    for t = 1:options.T
        old_cls = cls;

        Cs = Xs*nys;
        Zt = A'*Xt;
        
        Ct = Cs;
        ss = A*inv(A'*T*A)*A';
        
        if ~length(cls)
            model = fitcknn(Cs'*A, 1:size(Cs,2), 'NumNeighbors', 1, 'Distance', options.distance);
            cls = predict(model, Zt');
            acc = length(find((cls)==Yt))/length(Yt);  
            fprintf('Iteration %d: 1NN Acc = %0.4f\n', 0, acc);
        end
        if t == 1
            tp = full(sparse(1:nt,cls,1));
            tp = [tp, zeros(nt,max(Ys)-size(tp,2))];
            options.alpha = alpha*(sum(tp));
        end
        
        for j1 = 1:5
            old_Ct = Ct;
            tp = full(sparse(1:nt,cls,1));
            tp = [tp, zeros(nt,max(Ys)-size(tp,2))];
            nyt = tp*diag(1./(eps+sum(tp)));
            tp2 = sum(tp)+eps;
            Ct = (Cs*diag(options.alpha) + Xt*nyt*diag(tp2))*diag(1./(options.alpha+tp2));
            d1 = -Xt'*ss*Ct;
            d2 = Ct'*ss*Ct;
            d1 = 2*d1 + repmat(diag(d2),1,nt)';
            [~, b] = sort(d1,2);
            cls = b(:,1);
            acc = length(find((cls)==Yt))/length(Yt);

            if sum(sum(abs(old_Ct-Ct))) == 0
                break;
            end    

        end
        acc = length(find((cls)==Yt))/length(Yt);
        fprintf('Iteration %d: 1NN Acc = %0.4f\n', t, acc);
        M = (Cs - Ct)*diag(options.alpha)*(Cs-Ct)';

        tp = full(sparse(1:nt,cls,1));
        tp = [tp, zeros(nt,max(Ys)-size(tp,2))];            
        M0 = (Xt - Ct*tp')*(Xt - Ct*tp')';
        
        a1 = lu + M0 + M + options.lambda*speye(m);       
        [A,~] = eigs(a1, T, options.k, 'sm');   
        obj = trace((A'*a1*A)*inv(A'*T*A));
        output.obj = [output.obj, obj];
        fprintf('Iteration %d: obj = %.4f\n', t, obj);

        if size(old_cls,1) == size(cls,1) && sum(sum(abs(old_cls-cls))) == 0
            break;
        end       
    end 
    output.Ct = Ct;
    
    fprintf('**************************\n')
    acc2 = 0;
    if options.svm
        Zs = A'*Xs;
        Zt = A'*Xt;
        svmmodel = train(double(Ys), sparse(double(Zs')),'-s 1 -B 1 -q');
        [Cls,~,~] = predict(Yt, sparse(Zt)', svmmodel,'-q');
%         Cls = knnclassify(Zt',Zs',Ys,1); 
        acc2 = length(find(map(Cls)==Yt))/length(Yt); 
        fprintf('Final Accuracy: %0.4f\n',acc2);
    end
    output.iacc = [acc, acc2];
end