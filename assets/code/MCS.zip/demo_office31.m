warning off;
clear;close all;
srcStr = {'amazon','amazon','amazon','Caltech10','Caltech10','Caltech10','dslr','dslr','dslr','webcam','webcam','webcam'};
tgtStr = {'Caltech10','dslr','webcam','amazon','dslr','webcam','amazon','Caltech10','webcam','amazon','Caltech10','dslr'};
src2 = {'amazon','amazon','amazon','caltech','caltech','caltech','dslr','dslr','dslr','webcam','webcam','webcam'};
tgt2 = {'caltech','dslr','webcam','amazon','dslr','webcam','amazon','caltech','webcam','amazon','caltech','dslr'};

% office31
srcStr = {'amazon','amazon','dslr','dslr','webcam','webcam'};
tgtStr = {'dslr','webcam','amazon','webcam','amazon','dslr'};
src2 = {'amazon','amazon','dslr','dslr','webcam','webcam'};
tgt2 = {'dslr','webcam','amazon','webcam','amazon','dslr'};

% 150, 2, 0.1
options.k = 150;     %decaf 50  resenet 150       % subspace base dimension 200
options.ker = 'primal';     % kernel type, default='linear' options: linear, primal, gauss, poly
options.svm = 0;
options.lambda = 1;%0.5 for decaf 2 for resnet 2
options.alpha = 0.1;%1 for decaf % 0.5 default  %delta  0.1
options.T = 15;
options.distance = 'cosine'; %'euclidean'; %'cosine';

acc = [];
for iData = 1:6
    tic;
    src = char(srcStr{iData});
    tgt = char(tgtStr{iData});
    options.data = strcat(src,'-vs-',tgt);
    fprintf('Data=%s \n',options.data);
    type = 'ft-aaai-31decaf7';%'31-resnet';
%     type = '31-resnet';
    [CXs,CXt,CYs,CYt] = prepareoffice(src,tgt,type);
    options.xt = CXt;
    options.yt = CYt;
    options.xs = CXs;
    options.ys = CYs;
    tic;
    [~,out] = ours_cvpr(options);
    toc;
    acc = [acc;out.iacc];
end