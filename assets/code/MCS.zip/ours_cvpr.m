function [A,output] = ours_cvpr(options) 
    Xs = options.xs;
    Xt = options.xt;
    Ys = options.ys;
    Yt = options.yt;
    if ~isfield(options,'init')
        options.init = 0;
    end
    
    if ~isfield(options,'distance')
        options.distance = 'euclidean';
    end
  
    if ~isfield(options,'alpha')
        options.alpha = 2;
    end
    alpha = options.alpha;
    
    addpath('../src/liblinear-2.1/matlab')
    ns = size(Xs,2);
    nt = size(Xt,2);
    k = length(unique(Ys));

    Cls = [];
    Xs = normc(Xs);
    Xt = normc(Xt);
    
    if true     
        Xs = Xs - repmat(mean(Xs,2),1,size(Xs,2));
        Xt = Xt - repmat(mean(Xt,2),1,size(Xt,2));
        m = size(Xs,1);
    end

    X = [Xs, Xt];
    n = ns + nt;
    
    if options.init
        if isfield(options,'py')
            cls = options.py;
        else
            tp = full(sparse(1:ns,Ys,1));
            nys = tp*diag(1./sum(tp));
            cls = knnclassify(Xt',nys'*Xs',1:k,1); 
%             model = fitcknn(nys'*Xs',1:k, 'NumNeighbors', 1, 'Distance', options.distance);
%             cls = predict(model, Xt');
        end
    else
        cls = [];   
    end   

    % solve A
    Xs2 = Xs - repmat(mean(Xs,2),1,size(Xs,2));
    Xt2 = Xt - repmat(mean(Xt,2),1,size(Xt,2));
    T = Xs2*Xs2' + Xt2*Xt2';

    tp = full(sparse(1:ns,Ys,1));
    nys = tp*diag(1./sum(tp));
    lu = Xs - Xs*nys*tp';
    lu = lu*lu';

    [A,~] = eigs(lu+options.lambda*speye(m), T, options.k, 'sm');  
    output.iacc= [];

    for t = 1:options.T
        old_cls = cls;

        Cs = Xs*nys;
        Zt = A'*Xt;
        if ~length(cls)
            model = fitcknn(Cs'*A, 1:size(Cs,2), 'NumNeighbors', 1, 'Distance', options.distance);
            cls = predict(model, Zt');
            acc = length(find((cls)==Yt))/length(Yt);  
            fprintf('Iteration %d: 1NN Acc = %0.4f\n', 0, acc);
        end
        if t == 1
            tp = full(sparse(1:nt,cls,1));
            tp = [tp, zeros(nt,max(Ys)-size(tp,2))];
            options.alpha = alpha*(sum(tp));
        end
        Ct = Cs;
        for j1 = 1:5
            old_Ct = Ct;
            tp = full(sparse(1:nt,cls,1));
            tp = [tp, zeros(nt,max(Ys)-size(tp,2))];
            nyt = tp*diag(1./(eps+sum(tp)));
            tp2 = sum(tp)+eps;
            Ct = (Cs*diag(options.alpha) + Xt*nyt*diag(tp2))*diag(1./(options.alpha+tp2));
            model = fitcknn(Ct'*A, 1:size(Ct,2), 'NumNeighbors', 1, 'Distance', options.distance);
            cls = predict(model, Zt');
            
            if sum(sum(abs(old_Ct-Ct))) == 0
                break;
            end 
        end
        
        M = (Cs - Ct)*diag(options.alpha)*(Cs-Ct)';

        tp = full(sparse(1:nt,cls,1));
        tp = [tp, zeros(nt,max(Ys)-size(tp,2))];            
        M0 = (Xt - Ct*tp')*(Xt - Ct*tp')';
        
        a1 = lu + M0 + M + options.lambda*speye(m);
        [A,~] = eigs(a1, T, options.k, 'sm');        
        
        obj = trace((A'*a1*A))./trace(A'*T*A);
        acc = length(find((cls)==Yt))/length(Yt);
        fprintf('Iteration %d: 1NN Acc = %0.4f, obj = %.4f\n', t, acc, obj);
        if size(old_cls,1) == size(cls,1) && sum(sum(abs(old_cls-cls))) == 0
            break;
        end       
    end 
    output.Ct = Ct;
    
    fprintf('**************************\n')
    acc2 = 0;
    if options.svm
        Zs = A'*Xs;
        Zt = A'*Xt;
        svmmodel = train(double(Ys), sparse(double(Zs')),'-s 1 -B 1 -q');
        [Cls,~,~] = predict(Yt, sparse(Zt)', svmmodel,'-q');
%         Cls = knnclassify(Zt',Zs',Ys,1); 
        acc2 = length(find(map(Cls)==Yt))/length(Yt); 
        fprintf('Final Accuracy: %0.4f\n',acc2);
    end
    output.iacc = [acc, acc2];
end