function [Xs,Xt,Ys,Yt] = prepareoffice(src,tgt,type) 
    pathname = '../';
    switch type
        case 'vggf6'
            datapath = '/data/VGG-FC6';
            load(fullfile(pathname,datapath,[src,'_VGG-FC6.mat']));
            Xs = normr(FTS)';
%             Xs = (FTS)';
            Ys = LABELS';
            load(fullfile(pathname,datapath,[tgt,'_VGG-FC6.mat']));
            Xt = normr(FTS)';
%             Xt = FTS';
            Yt = LABELS';
        case 'vggf7'
            datapath = '/data/VGG-FC7';
            load(fullfile(pathname,datapath,[src,'_VGG-FC7.mat']));
            Xs = normr(FTS)';
%             Xs = (FTS)';
            Ys = LABELS';
            load(fullfile(pathname,datapath,[tgt,'_VGG-FC7.mat']));
            Xt = normr(FTS)';
%             Xt = FTS';
            Yt = LABELS';
        case 'decaf'
            datapath = '/data/Decaf'; %L2-norm
            load(fullfile(pathname,datapath,[src,'_decaf6.mat']));
            Xs = feas;
            Ys = labels;
            load(fullfile(pathname,datapath,[tgt,'_decaf6.mat']));
            Xt = feas;
            Yt = labels;
         case 'ft-aaai-31decaf6'
            datapath = '/data/Office31_alexnet/FT_Alexnet/'; %L2-norm
            load(fullfile(pathname,datapath,[src,'_',src,'_fc6.mat']));
            Xs = double(fts)';
            Ys = labels;
            load(fullfile(pathname,datapath,[src,'_',tgt,'_fc6.mat']));
            Xt = double(fts)';
            Yt = labels;
        case 'ft-aaai-31decaf7'
            datapath = '/data/Office31_alexnet/FT_Alexnet/'; %L2-norm
            load(fullfile(pathname,datapath,[src,'_',src,'_fc7.mat']));
            Xs = double(fts)';
            Ys = labels;
            load(fullfile(pathname,datapath,[src,'_',tgt,'_fc7.mat']));
            Xt = double(fts)';
            Yt = labels;   
     case '31-vgg'
            datapath = '/data/OFFICE31/';
            load(fullfile(pathname,datapath,['office-vgg-sumpool-',src,'-fc6.mat']));
%             Xs = normc(double(x'));
            Xs = (double(x'));
            Ys = double(y)';
            load(fullfile(pathname,datapath,['office-vgg-sumpool-',tgt,'-fc6.mat']));
%             Xt = normc(double(x)');
            Xt = (double(x)');
            Yt = double(y)';
%      case '31-resnet'
%             datapath = '/data/Office31_alexnet/resnet50/';
%             load(fullfile(pathname,datapath,[src,'_',src,'.mat']));
%             Xs = normc(double(fea'));
%             Ys = double(label)';
%             load(fullfile(pathname,datapath,[src,'_',tgt,'.mat']));
%             Xt = normc(double(fea)');
%             Yt = double(label)';
     case '31-resnet'
            datapath = '/data/Office31_alexnet/resnet50-twan/';
            load(fullfile(pathname,datapath,['office-31-',src,'-resnet50-no-augment.mat']));
            Xs = normc(double(x'));
            Ys = double(y)';
            load(fullfile(pathname,datapath,['office-31-',tgt,'-resnet50-no-augment.mat']));
            Xt = normc(double(x)');
            Yt = double(y)';
        case 'surf'
            datapath = 'data/Office-Caltech';
            load(fullfile(pathname,datapath,[src,'_SURF_L10.mat']));
            fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
            Xs = zscore(fts,1)';
            Ys = labels;
            load(fullfile(pathname,datapath,[tgt,'_SURF_L10.mat']));
            fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
            Xt = zscore(fts,1)';
            Yt = labels;
    end
    
end