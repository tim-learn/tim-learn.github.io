function [M] = solveM(B,V, n_iter)
%

% initialize with a orthogonal random rotation
bit = size(V,2);
rand('state',0);
M = randn(bit,bit);
[U11 S2 V2] = svd(M);
M = U11(:,1:bit);
UX = B;
% ITQ to find optimal rotation
for iter=0:n_iter
    Z = V * M;          
    C = UX' * V;
    [UB,sigma,UA] = svd(C);    
    M = UA * UB';
end

% make B binary



