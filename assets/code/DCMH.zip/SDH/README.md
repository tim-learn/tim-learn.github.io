# Discret Hashing

Code for the following paper:
-
Fumin Shen, Chunhua Shen, Wei Liu, Heng Tao Shen, "Supervised Discrete Hashing", IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2015.

1. The folder './testbed' contains the mat files used for this demo code. You can also download the files via http://pan.baidu.com/s/1ntHYDVb.

2. Run 'demo_SDH.m'. 
