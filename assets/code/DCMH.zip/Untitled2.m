for 
demo_DCMH()