function MAPXY = SCM(I_train, I_test,T_train,T_test,L_train, L_test,nbits,run,dataset)

for i = 1:run
    if size(L_train,2) == 1
        L_tr_temp =  full(sparse(1:size(L_train,1),L_train,1));
    else
        L_tr_temp = L_train;
    end
tic;
[SCMsWx, SCMsWy] = trainSCM_seq(I_train,T_train, nbits,L_tr_temp );trainTime = toc;
Yi_tr = sign((bsxfun(@minus, I_train*SCMsWx , mean(I_train*SCMsWx,1))));
Yi_te = sign((bsxfun(@minus, I_test *SCMsWx , mean(I_test *SCMsWx,1))));
Yt_tr = sign((bsxfun(@minus, T_train*SCMsWy , mean(T_train*SCMsWy,1))));
Yt_te = sign((bsxfun(@minus, T_test *SCMsWy , mean(T_test *SCMsWy,1))));

% Yi_tr = sign( I_train*SCMsWx );
% Yi_te = sign( I_test *SCMsWx );
% Yt_tr = sign(T_train*SCMsWy );
% Yt_te = sign(T_test *SCMsWy);



%%  storage
Result(i).dataset = dataset; Result(i).trainTime = trainTime; 
Result(i).Wx = SCMsWx; Result(i).Wy = SCMsWy; Result(i).nbits = nbits;
Result(i).Yi_tr = Yi_tr; Result(i).Yi_te = Yi_te; Result(i).Yt_tr = Yt_tr; Result(i).Yt_te = Yt_te; 
save(['./result/SCM_',dataset,'_',num2str(nbits),'bits'],'Result');
%% evaluate
fprintf('start evaluating...\n');

    Yi_te = logical(Yi_te+1);
    Yi_te = compactbit(Yi_te);
    Yt_te = logical(Yt_te+1);
    Yt_te = compactbit(Yt_te);
    
    Yi_tr = logical(Yi_tr+1);
    Yi_tr = compactbit(Yi_tr);
    Yt_tr = logical(Yt_tr+1);
    Yt_tr = compactbit(Yt_tr);
    
     hammingM = double(hammingDist(Yi_te, Yt_tr))';                
    MAPXY(i,1) = perf_metric4Label( L_train, L_test, hammingM );
     hammingM = double(hammingDist(Yt_te, Yi_tr))';                
    MAPXY(i,2) = perf_metric4Label( L_train, L_test, hammingM );


end

end

