bits = [16 24 32 64]
for bi = 1:length(bits)
    nbits = bits(bi);
    demo_DCMH(nbits);
end