function [W, P, B] = SDHforLinerg(X,y,B,fixB,S)

% ---------- Argument defaults ----------


lambda = 1e0;
eta = 1;
mu = 1e-1;
iters = 10;
nbits = size(B,2);
% ---------- End ----------

% label matrix N x c
if isvector(y) 
    Y = sparse(1:length(y), double(y), 1); Y = full(Y);
else
    Y = y;
end

while(iters)
% G-step

       W = (B'*B + lambda*eye(nbits))\B'*Y;


% G.Mg = Mg;
% F-step
      P = (X'*X + lambda*eye(size(X,2)))\X'*B;
      
% B-step
%      WY-eta*PX+mu*Bfix*c*S = (Bfix*Bfix'+W*W'-eta)*B  
     B = (fixB'*fixB + W*W' - eta*eye(nbits))\(W*Y'-eta*P'*X'+mu*fixB'*nbits*S);
     B = sign(B');
    
   iters = iters-1;
end
    

    
    
end