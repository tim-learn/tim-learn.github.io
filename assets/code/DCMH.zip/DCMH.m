function MAPXY = DCMH(I_train, I_test,T_train,T_test,L_train, L_test,nbits,run,dataset)
%%
kernel = 0 ; kmeansor = 0;
addpath(genpath('./SDH'));
addpath(genpath('../co-training CMF/framework/tool'));
%%

    X = I_train;
    Y = T_train;
    label = double(L_train);
    Ntrain = size(X,1);
    X_test = I_test;
    Y_test = T_test;
    
    
    if kernel
        % get anchors
        n_anchors = 500;
        if kmeansor
            opts = statset('Display', 'off', 'MaxIter', 100);
            [~, Ctemp] = kmeans(X, n_anchors, 'Start', 'sample', 'EmptyAction', 'singleton', 'Options', opts, 'OnlinePhase', 'off');
             anchorX = Ctemp;

             [~, Ctemp] = kmeans(Y, n_anchors , 'Start', 'sample', 'EmptyAction', 'singleton', 'Options', opts, 'OnlinePhase', 'off');
             anchorY = Ctemp;
        else
        rand('seed',1);
        anchorX = X(randsample(Ntrain, n_anchors),:);
        anchorY = Y(randsample(Ntrain, n_anchors),:);
        end
        
        sigma = 2; % for normalized data
        PhiX = exp(-sqdist(X,anchorX)/(2*sigma*sigma));
        PhiX = [PhiX, ones(Ntrain,1)];

        PhiY = exp(-sqdist(Y,anchorY)/(2*sigma*sigma));
        PhiY = [PhiY, ones(Ntrain,1)];

        Phi_testdataX = exp(-sqdist(X_test,anchorX)/(2*sigma*sigma)); 
        Phi_testdataX = [Phi_testdataX, ones(size(Phi_testdataX,1),1)];
        Phi_testdataY = exp(-sqdist(Y_test,anchorY)/(2*sigma*sigma)); 
        Phi_testdataY = [Phi_testdataY, ones(size(Phi_testdataY,1),1)];
    else
        PhiX = I_train;
        PhiY = T_train;
        Phi_testdataX = I_test; 
        Phi_testdataY = T_test;
    end
    
    if(size(I_train,1)>6000)
        trainNum = 5000;
        Index = randsample(length(L_train),trainNum);
        PhiX = PhiX(Index,:);
        PhiY = PhiY(Index,:);
        label = label(Index,:);
    end
    
    
    
    
    %%
    % learn G and F
    maxItr = 5;
    gmap.lambda = 1; gmap.loss = 'L2';
    Fmap.type = 'RBF';
    Fmap.nu = 1e-7; %  penalty parm for F term
    eta =  1e-5;    % ��ģ��ǰ���ϵ��
    Fmap.eta = eta*nbits;
    Fmap.lambda = 1e-2;
%% run algo

% Init Z
    randn('seed',3);
    Zinit=sign(randn(size(PhiX,1),nbits));
%% ITQ
%  addpath('./ITQ')
%  param.nbits =nbits;%round(avgbits); 
%  param.rand = 0;
%  param.gamma= 0.1;
%  param.lamda= 0.1;
%  data = T_train;   % init X modal or choose Y such as: data = Y; 
% %  % CCA-ITQ
%  param = trainITQCCA(data, L_train, param);  
%  [~,~,Zinit] = compressITQ(double(data), param); 
%  Zinit=sign( Zinit-0.5); 



%%

for i = 1:run
 
tic;
[F, H] = trainDCMH3(PhiX,PhiY,label,Zinit,gmap,Fmap,maxItr);
trainTime =  toc;
Wx = F.Px;
Wy = F.Py;


Yi_tr = sign((bsxfun(@minus, PhiX*Wx , mean(PhiX*Wx,1))));     
Yi_te = sign((bsxfun(@minus, Phi_testdataX *Wx , mean(Phi_testdataX *Wx,1))));
Yt_tr = sign((bsxfun(@minus, PhiY*Wy , mean(PhiY*Wy,1))));
Yt_te = sign((bsxfun(@minus, Phi_testdataY *Wy , mean(Phi_testdataY *Wy,1))));
%%  storage
Result(i).dataset = dataset; Result(i).trainTime = trainTime; 
Result(i).Wx = Wx; Result(i).Wy = Wy; Result(i).nbits = nbits;
Result(i).Yi_tr = Yi_tr; Result(i).Yi_te = Yi_te; Result(i).Yt_tr = Yt_tr; Result(i).Yt_te = Yt_te; 
save(['./result/DCMH_',dataset,'_',num2str(nbits),'bits'],'Result');

%% evaluate
fprintf('start evaluating...\n');

    Yi_te = logical(Yi_te+1);
    Yi_te = compactbit(Yi_te);
    Yt_te = logical(Yt_te+1);
    Yt_te = compactbit(Yt_te);
     hammingM = double(hammingDist(Yi_te, Yt_te))';                
    MAPXY(i,1) = perf_metric4Label( L_test, L_test, hammingM );
     hammingM = double(hammingDist(Yt_te, Yi_te))';                
    MAPXY(i,2) = perf_metric4Label( L_test, L_test, hammingM );

end
end

