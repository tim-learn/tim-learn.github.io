function [F, B] = trainDCMH(Xtrain,Ytrain,label,Zinit,gmap,Fmap,maxItr)
%%
%  X , Y ,L ���붼�� n*k�ģ���ʽ�ж��� k*n�ģ���ˣ���ʽ��ȡת��
% 
% * ITEM2
% 
%%

if isvector(label) 
    label = sparse(1:length(label), double(label), 1); label = full(label);
else
    label = label;
end

  if isvector(label)
    Stemp =  full(sparse(1:size(label,1),label,1));
  else
     Stemp = label; 
%       normalise = @(x) bsxfun(@rdivide, x, sqrt(sum(x.^2, 2)));
%      Stemp = normalise(Stemp);
  end
    S = Stemp*Stemp';
    S = double(2*S-1);
    
    

B1 = Zinit;
B2 = Zinit;
debug = 0;
%%  obtain B by discrete cyclic coordinatie descent
% B -step
loops = 3;
for loop = 1:loops
    [G1 F1 B1] = SDHforCM(Xtrain,label,B1,B2,gmap,Fmap,[],maxItr,debug,S);
    [G2 F2 B2] = SDHforCM(Ytrain,label,B2,B1,gmap,Fmap,[],maxItr,debug,S);
end



F.Px = F1.W;
F.Py = F2.W;
B.Bx = B1;
B.By = B2;


end

