function [  ] = demo_DCMH(nbits)
% % ���ݴ����ͺ�������
%%  hash code {+1,-1}
%%  data process
addpath(genpath('../co-training CMF/framework/data'));addpath(genpath('./tool'));addpath(genpath('./ITQ'));
% addpath(genpath('./SDH'));
dataset='wikiData'
% dataset='wiki_cnn_tfidf'
% dataset='VOC_random'
% dataset='VOC_cnn'
% dataset='labelme_tr75'
% dataset='VOC_FULL'
% dataset='VOC_full_cnn'
% dataset = 'NUS_WIDE'
% dataset = 'NUS_single'
load(dataset);

I_train = I_tr;
I_test = I_te;
T_train = full(T_tr);
T_test = full(T_te);

if exist('trY')&&exist('teY')
    L_train = trY;
    L_test = teY;
else
    L_train = L_tr;
    L_test = L_te;
end
 


%% %data normalized fixed

% %  normalise
    normalise = @(x) bsxfun(@rdivide, x, sqrt(sum(x.^2, 2)));
    I_train = normalise(I_train);
    I_test = normalise(I_test);
    T_train = normalise(T_train);
    T_test = normalise(T_test);

I_train = bsxfun(@minus, I_train, mean(I_train,1));
I_test = bsxfun(@minus, I_test, mean(I_train,1));
T_train = bsxfun(@minus, T_train, mean(T_train,1));
T_test = bsxfun(@minus, T_test, mean(T_train,1));
% 

%  
    
% I_train = bsxfun(@minus, I_train, mean(I_train,1));
% I_test = bsxfun(@minus, I_test, mean(I_train,1));
% T_train = bsxfun(@minus, T_train, mean(T_train,1));
% T_test = bsxfun(@minus, T_test, mean(T_train,1));


    

%     L_train = normalise(L_train);
%     L_test = normalise(L_test);

%% set the parameters

method = {'DCMH'};
MAP = zeros(length(method), 4); Time =  zeros(length(method), 1);
run = 1;     %��run������
% nbits = 16;

%% training and compute the project matrix

addpath(('./result'));
% % Ours
addpath(genpath('./SCM'));tic;
map = DCMH(I_train, I_test,T_train,T_test,L_train, L_test,nbits,run,dataset)
MAP(1,1:2) = mean(map,1) 
Time(1)=toc;
time = Time(1)/run

%% evaluation

%% output
disp(dataset);
fprintf('average map@ over %d runs for test-test \n Method   ImageQueryOnTextDB:      TextQueryOnImageDB:    runTime(s):\n',run);
for mm = 1:length(method)
fprintf('%5s :',char(method(mm)));
fprintf('   %.4f                   %.4f                 %.4f\n', MAP(mm,1), MAP(mm,2),Time(mm)/run);
end
% fprintf('average map@50 over %d runs for test-train \n Method   ImageQueryOnTextDB:      TextQueryOnImageDB:    runTime(s):\n',run);
% for mm = 1:length(method)
% % fprintf('%5s :',char(method(mm)));
% % fprintf('   %.4f                   %.4f                 %.4f\n', MAP(mm,3), MAP(mm,4),Time(mm)/run);
% end




