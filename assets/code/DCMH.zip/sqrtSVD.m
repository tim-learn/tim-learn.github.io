function U = sqrtSVD(M)
%M = U*U';
[UU S V] = svd(M);
U = sqrt(S)*UU;
end