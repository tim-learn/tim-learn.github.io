function MAPXY = DCMHICMR(I_train, I_test,T_train,T_test,L_train, L_test,nbits,run,dataset)
%%
% ����ICMR2016 ���� discriminant cross-modal hashing ���㷨
% ||Y-W��B||+||B-P��X||+||B-P'Y||
%%
    randn('seed',3);
    Binit=sign(randn(size(I_train,1),nbits));
    B = Binit';
    
    if size(L_train,2) == 1
        Y =  full(sparse(1:size(L_train,1),L_train,1))';
    else
        Y = L_train';
    end
    
    lamda = 1e-3;
    mu_v = 1e-1;
    mu_t = 1e-1;
   
    iters = 10;
  V = I_train';
  T = T_train';

  




%%

for i = 1:run
 
tic;
%% �Ż�
while (iters)
%step1 p 

  P_v = (V*V'+lamda*(eye(size(V,1))))\V*B';  %a\b=inv(a)*b   b/a=b*inv(a)
  P_t = (T*T'+lamda*(eye(size(T,1))))\T*B';
  
% step2 W 
  I = eye(size(B,1));
  W = (B*B'+lamda*I)\B*Y';
  
% step3 B
  I = eye(size(W,1));
  B = (W*W'+(mu_v+mu_t)*I)\(W*Y+mu_v*P_v'*V+mu_t*P_t'*T);
  B = sign(B);
%%
  iters = iters-1;
  
end
  


trainTime =  toc;
%%
Yi_tr = sign((bsxfun(@minus, I_train*P_v, mean(I_train*P_v,1))));     
Yi_te = sign((bsxfun(@minus, I_test*P_v , mean(I_test*P_v,1))));
Yt_tr = sign((bsxfun(@minus, T_train*P_t, mean(T_train*P_t,1))));
Yt_te = sign((bsxfun(@minus, T_test*P_t , mean(T_test*P_t,1))));
%%  storage

Result(i).dataset = dataset; Result(i).trainTime = trainTime; 
Result(i).Wx = P_v; Result(i).Wy = P_t; Result(i).nbits = nbits;
Result(i).Yi_tr = Yi_tr; Result(i).Yi_te = Yi_te; Result(i).Yt_tr = Yt_tr; Result(i).Yt_te = Yt_te; 
save(['./result/DCMHICMR_',dataset,'_',num2str(nbits),'bits'],'Result');




%% evaluate
fprintf('start evaluating...\n');

    Yi_te = logical(Yi_te+1);
    Yi_te = compactbit(Yi_te);
    Yt_te = logical(Yt_te+1);
    Yt_te = compactbit(Yt_te);
    
    hammingM = double(hammingDist(Yi_te, Yt_te))';                
    MAPXY(i,1) = perf_metric4Label( L_test, L_test, hammingM );
     hammingM = double(hammingDist(Yt_te, Yi_te))';                
    MAPXY(i,2) = perf_metric4Label( L_test, L_test, hammingM );
    
    
    Yi_tr = logical(Yi_tr+1);
    Yi_tr = compactbit(Yi_tr);
    Yt_tr = logical(Yt_tr+1);
    Yt_tr = compactbit(Yt_tr);
    

%      hammingM = double(hammingDist(Yi_te, Yt_tr))';                
%     MAPXY(i,1) = perf_metric4Label( L_train, L_test, hammingM );
%      hammingM = double(hammingDist(Yt_te, Yi_tr))';                
%     MAPXY(i,2) = perf_metric4Label( L_train, L_test, hammingM );

end
end

