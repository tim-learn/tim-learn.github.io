function [ out ] = zhengjiao( in )
    % in n*d
    c = in'*in;
    [u,s,v] = svd(c,'econ');
    ss = sqrt(diag(s));
    ss(ss>0) = 1./ss(ss>0);
    out = u*diag(ss)*v'; 
    out = in*out;
end

