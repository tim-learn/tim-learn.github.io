function MAPXY = evaluteMap(Yi_tr,Yi_te,Yt_tr,Yt_te,L_train, L_test,i);

MAPXY = zeros(1,2);
% test-train
% fprintf('start evaluating...\n');
% simi_t = Yt_tr * Yi_te';   
% simt_i = Yi_tr * Yt_te';    %query �ں���
% MAPXY(3) = mAP(simi_t,L_train,L_test);
% MAPXY(4) = mAP(simt_i,L_train,L_test);

% test-test
simi_t = Yt_te * Yi_te';   
simt_i = Yi_te * Yt_te';    %query �ں���
MAPXY(1) = mAP(simi_t,L_test,L_test);
MAPXY(2) = mAP(simt_i,L_test,L_test);

end