function [Xpca,pc] = pCA(X, dim_temp)
%X �Ѿ�ȥ��ֵ
C = cov(X);
[pc, l] = eigs(C, dim_temp);
Xpca = X*pc;
end