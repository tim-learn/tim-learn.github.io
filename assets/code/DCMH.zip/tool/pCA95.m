function [Xpca,Newpc] = pCA95(X)
%X �Ѿ�ȥ��ֵ
C = cov(X);
% if size(C,1) > 1000
%     [Newpc, ~] = eigs(C,200);
% else    
    num = size(C,1)-1;
    [pc, l] = eigs(C,num);
    l = diag(l);
    Sumeigs = sum(l);
    threshold = Sumeigs*0.95;
    while(num)
        Sumeigs = Sumeigs - l(num);
        if Sumeigs <= threshold
            signal = num;
            break;
        end    
        num = num - 1;
    end
    Newpc = pc(:,1:signal);    
% end

Xpca = X*Newpc;
end