function Mg = gerneryM(H1,H2,Y)

M = [H1 H2];
temp = M*M';
S = sqrtSVD(temp);
SS = inv(S);
A = sqrtSVD(SS);
[U,S,V] = svd(cov(A));
reduced_A = A*U(:,1:size(H1,2));
B = reduced_A';
temp = B*B';
Mg = sqrtSVD(temp);
[U,S,V] = svd(cov(Mg));
Mg = Mg*U(:,1:size(Y,2));
end