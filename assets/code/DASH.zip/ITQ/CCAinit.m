function pc = CCAinit(data, Label,nbits )
%
% code for converting data X to binary code C using ITQ
% Input:
%       X: n*d data matrix, n is number of images, d is dimension
%       bit: number of bits
% Output:      
%       C: n*bit binary code matrix
% 
% Yunchao Gong (yunchao@cs.unc.edu)
%

X = double(data);
% center the data, VERY IMPORTANT for ITQ to work
bit = nbits;
sampleMean = mean(X,1);
X = (X - repmat(sampleMean,size(X,1),1));

%%
% CCA
[n_tr,~] = size(X);
if size(Label,2)==1
    nCats=length(unique(Label));
    Y=zeros(nCats,n_tr);
    for i=1:nCats
        Y(i,Label==i)=1;
    end
else
    Y = Label';
    normalise = @(x) bsxfun(@rdivide, x, sqrt(sum(x.^2, 1)));
    Y = normalise(Y);
end


[wx] = cca(X',Y);

% add by liang
wx = repmat(wx,[1,10]);
%%%%%%%%%%%%%%%%%%%%
pc = real(wx(:,1:bit));


end


