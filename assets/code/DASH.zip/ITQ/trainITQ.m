function ITQparam = trainITQ(data, ITQparam)
%
% code for converting data X to binary code C using ITQ
% Input:
%       X: n*d data matrix, n is number of images, d is dimension
%       bit: number of bits
% Output:      
%       C: n*bit binary code matrix
% 
% Yunchao Gong (yunchao@cs.unc.edu)
%

X = double(data);
% center the data, VERY IMPORTANT for ITQ to work
bit = ITQparam.nbits;
sampleMean = mean(X,1);
X = (X - repmat(sampleMean,size(X,1),1));

% PCA
C = cov(X);
[pc, l] = eigs(C, bit);
XX = X*pc;


if(ITQparam.rand)
    R = randn(size(XX,2),bit);
    [U S V] = svd(R);
    R = U(:,1:bit);
    XX = XX*R;
    C = XX>0;
else
    % ITQ to find optimal rotation
    % default is 50 iterations
    % C is the output code
    % R is the rotation found by ITQ
    [C, R] = ITQ(XX,50);
end

ITQparam.pc = pc;
ITQparam.R = R;
% ITQparam.C = C;
ITQparam.sampleMean = sampleMean;        


