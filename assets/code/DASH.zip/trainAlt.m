function [ Wx, Wy ] = trainAlt(X, Y, nbits, L, Wx, Wy)

nData = size(X, 1);
dX = size(X, 2);
dY = size(L, 2);
lambda = 1e-02;


% computes CCA projections if not inputed
if (exist('Wx', 'var') && exist('Wy', 'var'))
    Wx=Wx;Wy=Wy;
    return ;
end

%% ITQ
param.nbits =nbits;%round(avgbits); 
param.rand = 0;
param.gamma= 0.1;
param.lamda= 0.001;
data = Y;   % init X modal or choose Y such as: data = Y; 
param = trainITQCCA(data, L, param);  

[~,~,Hy] = compressITQ(double(data), param); 
Xpc = CCAinit(X,L,nbits);
X = X*Xpc;   
%% compute iteratively
Wx = (X'*X + lambda*eye(size(X, 2)))\(X'*Hy); 
Wy = param.pc*param.R;
Wx = Xpc * Wx;

end

