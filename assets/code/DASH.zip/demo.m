function [ map ] = demo(nbits,dataset)
% I_te n_te*d_i
% T_te n_tr*d_t
% L_te n_te*c  or teY n_te*1
%%  data process
addpath(genpath('./ITQ'));
load(dataset);

% % 
I_train =double(I_tr);
I_test = double(I_te);
T_train = full(T_tr);
T_test = full(T_te);

dopca = 0;
if dopca
    [T_train, pc] = pCA95(T_train); T_test = T_test*pc;
    [I_train, pc] = pCA95(I_train);  I_test = I_test*pc;
end

% L_train {0,1}^{n_tr*c}
if exist('trY') && exist('teY')
    L_train = SY2MY(trY);
    L_test = SY2MY(teY);
else
    L_train = L_tr;
    L_test = L_te;
end

%% %data normalized fixed
Imean = mean(I_train,1);
I_train = bsxfun(@minus, I_train,Imean );
I_test = bsxfun(@minus, I_test, Imean);
Tmean = mean(T_train,1);
T_train = bsxfun(@minus, T_train, Tmean);
T_test = bsxfun(@minus, T_test, Tmean);

if size(T_test,2)<nbits
    Temp = repmat(T_test,[1,20]);
    T_test = Temp(:,1:nbits+10); 
    Temp = repmat(T_train,[1,20]);
    T_train = Temp(:,1:nbits+10);
end
[Wx, Wy] = trainAlt(I_train,T_train, nbits, L_train);
% or
%[Wy, Wx] = trainAlt(T_train,I_train, nbits, L_train);

% Y: n*nbits
%Yi_tr = sign(I_train*Wx);     Yt_tr = sign(T_train*Wy);
Yi_te = sign(I_test *Wx);     Yt_te = sign(T_test *Wy);


%% evaluate
fprintf('start evaluating...\n');
Yi_te = compactbit(Yi_te>=0);
Yt_te = compactbit(Yt_te>=0);
hammingM = double(hammingDist(Yi_te, Yt_te))';                
map(1) = perf_metric4Label(L_test, L_test, hammingM );
hammingM = double(hammingDist(Yt_te, Yi_te))';                
map(2) = perf_metric4Label(L_test, L_test, hammingM );
end



