function [Xs,Xt,Ys,Yt] = prepareoffice(src,tgt,type) 

    switch type
        case 'vggf6'
            datapath = '..\data\VGG-FC6';
            load(fullfile(datapath,[src,'_VGG-FC6.mat']));
            Xs = normr(FTS)';
            Ys = LABELS';
            load(fullfile(datapath,[tgt,'_VGG-FC6.mat']));
            Xt = normr(FTS)';
            Yt = LABELS';
        case 'vggf7'
            datapath = '..\data\VGG-FC7';
            load(fullfile(datapath,[src,'_VGG-FC7.mat']));
            Xs = normr(FTS)';
            Ys = LABELS';
            load(fullfile(datapath,[tgt,'_VGG-FC7.mat']));
            Xt = normr(FTS)';
            Yt = LABELS';
        case 'decaf'
            datapath = '../data/Decaf'; %L2-norm
            load(fullfile(datapath,[src,'_decaf6.mat']));
            Xs = feas;
            Ys = labels;
            load(fullfile(datapath,[tgt,'_decaf6.mat']));
            Xt = feas;
            Yt = labels;
        case 'surf'
            datapath = '../data';
            load(fullfile(datapath,[src,'_SURF_L10.mat']));
            fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
            Xs = zscore(fts,1)';
            Ys = labels;
            load(fullfile(datapath,[tgt,'_SURF_L10.mat']));
            fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
            Xt = zscore(fts,1)';
            Yt = labels;
    end
    
end