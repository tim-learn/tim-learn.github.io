function [acc,acc2,A] = ours(options) 
    Xs = options.xs;
    Xt = options.xt;
    Ys = options.ys;
    Yt = options.yt;
    if ~isfield(options,'svm')
        options.svm = 1;
    end
    if ~isfield(options,'weight')
        options.weight = 1;
    end
    if ~isfield(options,'init')
        options.init = 0;
    end
    
    Cls = [];  
    if options.init
        Cls = knnclassify(Xt',Xs',Ys,1); 
    end
    for t = 1:options.T
        fprintf('==============================Iteration [%d]==============================\n',t);
        [Z, A] = DICE(Xs,Xt,Ys,Cls,options);
        Z = Z*diag(sparse(1./sqrt(sum(Z.^2))));
        Zs = Z(:,1:size(Xs,2));
        Zt = Z(:,size(Xs,2)+1:end);
        Cls = knnclassify(Zt',Zs',Ys,1);

        if options.b
            W = kernel('rbf',Z,[],10);
            W = W - diag(diag(W));
            D = diag(sum(W));
            y = full(sparse(1:size(Z,2),[Ys;Cls],1));
            iii = 1;
            while iii <2
                y = (D - options.alpha*W)\y;
                iii = iii + 1;
            end
            
            [~,tmp] = sort(y,2);
            ns = size(Zs,2);
            Cls = tmp(ns+1:end,end);
            acc = length(find(Cls==Yt))/length(Yt); fprintf('LP=%0.4f\n',acc);
        end
    end
    acc = length(find(Cls==Yt))/length(Yt); fprintf('1NN Acc = %0.4f\n',acc);
    fprintf('**************************\n***************************')
    fprintf('\n\n\n');
        
    if options.svm
        addpath('..\liblinear-2.1\matlab\') 
        svmmodel = train(double(Ys), sparse(double(Zs')),'-s 1 -B 1 -q');
        [Cls,~,~] = predict(Yt, sparse(Zt)', svmmodel,'-q');
        acc2 = length(find(Cls==Yt))/length(Yt); fprintf('Final Accuracy: %0.4f\n',acc2);
    else 
        acc2 = 0;
    end
end
