clear all;
clc;
warning off;
srcStr = {'amazon','amazon','amazon','Caltech10','Caltech10','Caltech10','dslr','dslr','dslr','webcam','webcam','webcam'};
tgtStr = {'Caltech10','dslr','webcam','amazon','dslr','webcam','amazon','Caltech10','webcam','amazon','Caltech10','dslr'};
src2 = {'amazon','amazon','amazon','caltech','caltech','caltech','dslr','dslr','dslr','webcam','webcam','webcam'};
tgt2 = {'caltech','dslr','webcam','amazon','dslr','webcam','amazon','caltech','webcam','amazon','caltech','dslr'};

datapath = '..\data\DataSplitsOfficeCaltech';

options.k = 10;             % subspace base dimension
options.ker = 'primal';     % kernel type, default='linear' options: linear, primal, gauss, poly
% options.ker = 'linear';
options.lambda = 0.1;   
options.T = 10; % iterations
options.weight = 1;

options.b = 0;
options.alpha = 0.8;

ffid = fopen('result0.txt','at');
fprintf(ffid, '****************************\n %s\n', datestr(now));
fprintf(ffid, 'dim = %d, \t kernel = %s \n******************************\n', options.k,options.ker);

results = [];
for iData = 1:12
    src = char(srcStr{iData});
    tgt = char(tgtStr{iData});
    options.data = strcat(src,'-vs-',tgt);
    fprintf('Data=%s \n',options.data);
    type = 'surf';
    [CXs,CXt,CYs,CYt] = prepareoffice(src,tgt,type);
    options.xt = CXt;
    options.yt = CYt;
    
    src = char(src2{iData});
    tgt = char(tgt2{iData});
    splitdata = ['SameCategory_', src, '-', tgt, '_20RandomTrials_10Categories.mat'];
    load(fullfile(datapath,splitdata));
    acc = zeros(length(train.source),2);
    for sp = 1: length(train.source)
        inds = train.source{sp};
        nXs = CXs(:,inds);
        nYs = CYs(inds);
        options.xs = nXs;
        options.ys = nYs;
        fprintf('%d iterions\n',sp);
        [temp1,temp2] = ours(options);
        acc(sp,:) = 100*[temp1 temp2];
    end
    
    macc = mean(acc);
    sacc = std(acc);
    results = [results; macc];

    fprintf('%s : \n NN mean accuracy: %.2f + %.2f\n***************************\n',options.data, macc(1), sacc(1));
    fprintf(ffid,'%s : \n NN mean accuracy: %.2f + %.2f\n***************************\n',options.data, macc(1), sacc(1));
    fprintf('%s : \n SVM mean accuracy: %.2f + %.2f\n***************************\n',options.data, macc(2), sacc(2));
    fprintf(ffid,'%s : \n SVM mean accuracy: %.2f + %.2f\n***************************\n',options.data, macc(2), sacc(2));
    
end
fclose(ffid);