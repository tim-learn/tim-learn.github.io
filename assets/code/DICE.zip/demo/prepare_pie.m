function [Xs,Xt,Ys,Yt] = prepare_pie(src,tgt,type)  
% 	datapath = '/DATA/jian.liang/da_jian/data';  
    datapath = 'E:/DA17/data/';
	switch type
        case 'l2'
		% Preprocess data using L2-norm
			load(fullfile(datapath, 'PIE', [src '.mat']));
			Xs = fts';
			Xs = Xs*diag(sparse(1./sqrt(sum(Xs.^2))));
			Ys = labels;
			load(fullfile(datapath, 'PIE', [tgt '.mat']));  
			Xt = fts';
			Xt = Xt*diag(sparse(1./sqrt(sum(Xt.^2))));
			Yt = labels;
		case 'zscore'
			load(fullfile(datapath, 'PIE', [src '.mat']));
    		fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
			Xs = zscore(fts,1)';
			Ys = labels;
			load(fullfile(datapath, 'PIE', [tgt '.mat']));  
			fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
			Xt = zscore(fts,1)';
			Yt = labels;
		case 'ori'
			load(fullfile(datapath, 'PIE', [src '.mat']));
			Xs = fts';
			Ys = labels;
			load(fullfile(datapath, 'PIE', [tgt '.mat']));  
			Xt = fts';
			Yt = labels;
	end
end