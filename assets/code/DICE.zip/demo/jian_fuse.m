function [score, nn_score] =  jian_fuse(options, A)
    Xs = options.xs;
    Ys = options.ys;
    Xt = options.xt;
    Yt = options.yt;
    K = length(A);
    ns = length(Ys);
    nt = length(Yt);
    
    %%
    X = [Xs,Xt];
    X = X*diag(sparse(1./sqrt(sum(X.^2))));
    
    Fea = [];
    for iter = 1:K
        temp = A{iter}'*X;
        temp = temp*diag(sparse(1./sqrt(sum(temp.^2))));
        Fea = [Fea;temp];
    end
    
    % feature-level fusion
    Zs = Fea(:,1:ns);
    Zt = Fea(:,ns+1:end);

    svmmodel = train(double(Ys), sparse(double(Zs')),'-s 1 -B 1 -q');
    Cls = predict(Yt, sparse(Zt)', svmmodel,'-q');
    acc1 = length(find(Cls==Yt))/length(Yt); 
    fprintf('Conv-SVM Acc = %0.2f\n', 100*acc1);
    
    Cls = knnclassify(Zt',Zs',Ys,1);
    acc2 = length(find(Cls==Yt))/length(Yt); 
    fprintf('Conv-1NN Acc = %0.2f\n', 100*acc2);
    
    nn_vote = zeros(nt,max(Ys));
    svm_vote = zeros(nt,max(Ys));
    % svm_vote2 = zeros(nt,max(Ys));
    weighted_nn = zeros(nt,max(Ys));
    nn_score = [];
    for iter = 1:K
        temp = A{iter}'*X;
        temp = temp*diag(sparse(1./sqrt(sum(temp.^2))));
        Zs = temp(:,1:ns);
        Zt = temp(:,ns+1:end);
        
        % nn
        Cls = knnclassify(Zt',Zs',Ys,1);
        acc = length(find(Cls==Yt))/length(Yt); 
        fprintf('1-NN Classifier Acc = %0.2f\n', 100*acc);
        nn_vote(:,1:max(Cls)) = nn_vote(:,1:max(Cls)) + full(sparse(1:nt,Cls,1));
        
        % WEIGHTED NN
        IDX = knnsearch(Zs',Zt','K', 10);
        weigt = sum(Ys(IDX)-repmat(Ys(IDX(:,1)),1,knn)==0,2)/knn;
        weighted_nn(:,1:max(Cls)) = weighted_nn(:,1:max(Cls)) + full(sparse(1:nt,Cls,weigt));
        
        % svm
        svmmodel = train(double(Ys), sparse(double(Zs')),'-s 1 -B 1 -q');
        Cls = predict(Yt, sparse(Zt)', svmmodel,'-q');
        svm_vote(:,1:max(Cls)) = svm_vote(:,1:max(Cls)) + full(sparse(1:nt,Cls,1));
                
        % svm_vote2(:,1:max(Cls)) = svm_vote2(:,1:max(Cls))  + full(sparse(1:nt,Cls,1));
        nn_score = [nn_score, acc];
    end 
    
    [~,idx] = sort(nn_vote,2);
    acc3 = sum(idx(:,end)==Yt)/length(Yt);
    fprintf('MV-1NN Acc = %0.2f\n', 100*acc3);
 
    [~,idx] = sort(svm_vote,2);
    acc4 = sum(idx(:,end)==Yt)/length(Yt);
    fprintf('MV-SVM Acc = %0.2f\n', 100*acc4);
    
    [~,idx] = sort(weighted_nn,2);
    acc0 = sum(idx(:,end)==Yt)/length(Yt);
    fprintf('WMV-1NN Acc = %0.2f\n', 100*acc0);

    score = [acc1, acc2, acc3, acc4, acc0] * 100;
    nn_score = nn_score * 100;

end