clear all;
clc;
warning off;
srcStr = {'amazon','amazon','amazon','Caltech10','Caltech10','Caltech10','dslr','dslr','dslr','webcam','webcam','webcam'};
tgtStr = {'Caltech10','dslr','webcam','amazon','dslr','webcam','amazon','Caltech10','webcam','amazon','Caltech10','dslr'};
src2 = {'amazon','amazon','amazon','caltech','caltech','caltech','dslr','dslr','dslr','webcam','webcam','webcam'};
tgt2 = {'caltech','dslr','webcam','amazon','dslr','webcam','amazon','caltech','webcam','amazon','caltech','dslr'};

options.k = 10;             % subspace base dimension
options.ker = 'primal';     % kernel type, default='linear' options: linear, primal, gauss, poly
% options.ker = 'linear';
% options.ker = 'rbf';
options.gamma = 1.0;
options.lambda = 0.1;   
options.T = 10; % iterations
options.weight = 1;
% options.svm = 0;
% options.init = 1;

options.b = 0;
options.alpha = 0.8;

ffid = fopen('result.txt','at');
fprintf(ffid, '****************************\n %s\n', datestr(now));
fprintf(ffid, 'dim = %d, \t kernel = %s \n******************************\n', options.k,options.ker);

acc = [];
for iData = 1:12
    src = char(srcStr{iData});
    tgt = char(tgtStr{iData});
    options.data = strcat(src,'-vs-',tgt);
    fprintf('Data=%s \n',options.data);
    type = 'surf';
    [CXs,CXt,CYs,CYt] = prepareoffice(src,tgt,type);
    options.xt = CXt;
    options.yt = CYt;
    options.xs = CXs;
    options.ys = CYs;
    [temp1, temp2] = ours(options);
    acc = [acc; temp1,temp2];
    fprintf('%s : \n NN mean accuracy: %.2f \n***************************\n',options.data, 100*temp1);
    fprintf(ffid,'%s : \n NN mean accuracy: %.2f \n***************************\n',options.data, 100*temp1);

    fprintf('%s : \n SVM mean accuracy: %.2f \n***************************\n',options.data, 100*temp2);
    fprintf(ffid,'%s : \n SVM mean accuracy: %.2f\n***************************\n',options.data, 100*temp2);

end
fclose(ffid);