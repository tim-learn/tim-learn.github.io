clear all;
clc;
warning off;

% Set algorithm parameters
options.k = 100;             % subspace base dimension
options.ker = 'primal';     % kernel type, default='linear' options: linear, primal, gauss, poly
% options.ker = 'linear';
options.lambda = 0.01;   
options.T = 10; % iterations
options.weight = 1;

options.b = 0;
options.alpha = 0.8;

options.svm = 0;
% options.init = 1;
addpath('../liblinear-2.1/matlab/')    
    
S1 = 1.8;
S2 = 1.8;
Sf = 0.5;
K = 10;
A = cell(K,1);

srcStr = {'PIE05','PIE05','PIE05','PIE05','PIE07','PIE07','PIE07','PIE07','PIE09','PIE09','PIE09','PIE09','PIE27','PIE27','PIE27','PIE27','PIE29','PIE29','PIE29','PIE29'};
tgtStr = {'PIE07','PIE09','PIE27','PIE29','PIE05','PIE09','PIE27','PIE29','PIE05','PIE07','PIE27','PIE29','PIE05','PIE07','PIE09','PIE29','PIE05','PIE07','PIE09','PIE27'};

name = ['pie-',num2str(zz),'-',num2str(K),'-', num2str(S1),'-', num2str(S2),'.txt'];
ffid = fopen(name,'at');
fprintf(ffid, '****************************\n %s\n', datestr(now));
fprintf(ffid, 'dim = %d, \t kernel = %s \n******************************\n', options.k,options.ker);
fprintf(ffid, 'weight = %.2f \n******************************\n', options.weight);
fprintf(ffid, 'S1 = %.2f \t S2 = %.2f \t Sf = %.2f \n******************************\n', S1,S2,Sf);

results = [];
for zzz = 1:1
for iData = 11:20%[3,10,13]%[4,7,14]
    src = char(srcStr{iData});
    tgt = char(tgtStr{iData});
    options.data = strcat(src,'_vs_',tgt);
    % Preprocess data using L2-norm
    [CXs,CXt,CYs,CYt] = prepare_pie(src,tgt,'l2');
    %%
    options2.xt = CXt;
    options2.yt = CYt;
    options2.xs = CXs;
    options2.ys = CYs;

    for iiter = 1:K
        sf = rand(size(CXs,1),1) < Sf;
        s1 = rand(length(CYs),1) < S1;
        options.xs = CXs(sf,s1);
        options.ys = CYs(s1);
        Sub{iiter} = s1;
        s2 = rand(length(CYt),1) < S2;
        options.xt = CXt(sf,s2);
        options.yt = CYt(s2);
        [temp1, temp2, pf] = ours(options);
        ttp = zeros(size(CXs,1),size(pf,2));
        ttp(sf,:) = pf;
        A{iiter} = ttp; % d*subd
    end

    % fuse K sub-projection
    iacc = fuse(options2, A);
    fprintf(ffid,'Feature-level SVM Classifier Acc = %0.2f\n', 100*iacc(1));
    fprintf(ffid,'Feature-level 1-NN Classifier Acc = %0.2f\n', 100*iacc(2));
    fprintf(ffid,'Majority Vote of 1-NN Classifier Acc = %0.2f\n', 100*iacc(3));
    fprintf(ffid,'Majority Vote of SVM Classifier Acc = %0.2f\n', 100*iacc(4));
    fprintf(ffid,'Weighted NN Acc = %0.2f\n', 100*iacc(5));
    results = [results;iacc];
    fprintf(ffid,'***************************\n%s : \n mean accuracy: \n',options.data);
    fprintf(ffid,'%.2f\n', acc);
    
    fprintf(ffid,'\n\n\n$$$$$$$$$$$$$$$$$$$$\n$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n');
end
end
fclose(ffid);
[S1,S2,K,zz]