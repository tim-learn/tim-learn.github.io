clear all;
clc;
warning off;
% Set algorithm parameters
options.k = 100;             % subspace base dimension
options.ker = 'primal';     % kernel type, default='linear' options: linear, primal, gauss, poly
% options.ker = 'linear';
options.lambda = 0.01;   
options.T = 10; % iterations
options.weight = 1;
options.b = 0;
options.alpha = 0.8;


srcStr = {'PIE05','PIE05','PIE05','PIE05','PIE07','PIE07','PIE07','PIE07','PIE09','PIE09','PIE09','PIE09','PIE27','PIE27','PIE27','PIE27','PIE29','PIE29','PIE29','PIE29'};
tgtStr = {'PIE07','PIE09','PIE27','PIE29','PIE05','PIE09','PIE27','PIE29','PIE05','PIE07','PIE27','PIE29','PIE05','PIE07','PIE09','PIE29','PIE05','PIE07','PIE09','PIE27'};

ffid = fopen('result_pie.txt','at');
fprintf(ffid, '****************************\n %s\n', datestr(now));
fprintf(ffid, 'dim = %d, \t kernel = %s \n******************************\n', options.k,options.ker);
fprintf(ffid, 'weight = %.2f \n******************************\n', options.weight);
fprintf(ffid, 'no inintiation ****************************\n');

results = [];
ttime = [];
for iData = 1:20%[3,10,13]%[4,7,14]
    src = char(srcStr{iData});
    tgt = char(tgtStr{iData});
    options.data = strcat(src,'_vs_',tgt);
    % Preprocess data using L2-norm
    [CXs,CXt,CYs,CYt] = prepare_pie(src,tgt,'l2');
    %%
    options.xt = CXt;
    options.yt = CYt;
    options.xs = CXs;
    options.ys = CYs;
    %%
    tic;
    [iacc,iacc2]= ours(options);
    ttime = [ttime,toc];
    
    acc = 100*iacc;
    results = [results;iacc, iacc2];
    fprintf(ffid,'***************************\n%s : \n mean accuracy: \n',options.data);
    fprintf(ffid,'%.2f\n', acc);
    
    fprintf(ffid,'\n\n\n$$$$$$$$$$$$$$$$$$$$\n$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n');
end
fclose(ffid);