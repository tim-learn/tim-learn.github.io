function [Z,A] = DICE(Xs,Xt,Ys,Yt0,options)
% Load algorithm options
addpath(genpath('../liblinear/matlab'));

if nargin < 5
    error('Algorithm parameters should be set!');
end
if ~isfield(options,'k')
    options.k = 100;
end
if ~isfield(options,'lambda')
    options.lambda = 0.1;
end
if ~isfield(options,'ker')
    options.ker = 'primal';
end
if ~isfield(options,'gamma')
    options.gamma = 1.0;
end
if ~isfield(options,'data')
    options.data = 'default';
end
k = options.k;
lambda = options.lambda;
ker = options.ker;
gamma = options.gamma;
data = options.data;

fprintf('DICE:  data=%s  k=%d  lambda=%f\n',data,k,lambda);

% Set predefined variables
X = [Xs, Xt];
X = X*diag(sparse(1./sqrt(sum(X.^2))));

[m,n] = size(X);
ns = size(Xs,2);
nt = size(Xt,2);
C = length(unique(Ys));

L = zeros(ns+nt);
% build SOURCE-LDA
tp = full(sparse(1:ns,Ys,1));
tp2 = tp*diag(1./sum(tp));
tp3 = tp2*tp';
tp4 = (tp3 - eye(ns));
L(1:ns,1:ns) = tp4*tp4';

% Construct MMD matrix
e = [1/ns*ones(ns,1);-1/nt*ones(nt,1)];
M = e*e'*C;

if ~isempty(Yt0) && length(Yt0)==nt
    
    we = ones(max(Ys),1);
    for c = reshape(unique(Ys),1,C)
        e = zeros(n,1);
        e(Ys==c) = 1/length(find(Ys==c));
        e(ns+find(Yt0==c)) = -1/length(find(Yt0==c));
        e(isinf(e)) = 0;
        M = M + we(c)*e*e';
    end
    
    tp = full(sparse(1:nt,Yt0,1));
    tp2 = tp*diag(1./(1e-4+sum(tp)));
    tp3 = tp2*tp';
    tp4 = (tp3 - eye(nt));

    p = 1;
    L(ns+1:end,ns+1:end) = p * (tp4*tp4');
    
end

M = M/norm(M,'fro');
L = L/norm(L,'fro');

M = M + options.weight*L;


% Construct centering matrix
H = eye(n)-1/(n)*ones(n,n);

opts.tol = 1e-1; 
if strcmp(ker,'primal')
    T = X*H*X';
    [A,~] = eigs(X*M*X'+lambda*eye(m), T,k,'SM');
    Z = A'*X;
else
    K = kernel(ker,X,[],gamma);
    [A,~] = eigs(K*M*K'+lambda*eye(n), K*H*K',k,'SM');
    Z = A'*K;
end
end
