clear all;
clc;
warning off;
addpath('../liblinear-2.1/matlab')
srcStr = {'amazon','amazon','amazon','Caltech10','Caltech10','Caltech10','dslr','dslr','dslr','webcam','webcam','webcam'};
tgtStr = {'Caltech10','dslr','webcam','amazon','dslr','webcam','amazon','Caltech10','webcam','amazon','Caltech10','dslr'};
src2 = {'amazon','amazon','amazon','caltech','caltech','caltech','dslr','dslr','dslr','webcam','webcam','webcam'};
tgt2 = {'caltech','dslr','webcam','amazon','dslr','webcam','amazon','caltech','webcam','amazon','caltech','dslr'};

options.k = 10;             % subspace base dimension
options.ker = 'primal';     % kernel type, default='linear' options: linear, primal, gauss, poly
% options.ker = 'linear';
options.lambda = 0.1;   
options.T = 10; % iterations
options.weight = 1;
options.svm = 0;

options.b = 0;
options.alpha = 0.8;

S1 = 0.8;
S2 = 0.6;
Sf = 0.9;
K = 10;
A = cell(K,1);

%type = 'decaf';
type = 'surf';


name = ['office-', type,num2str(zz),'-',num2str(K),'-', num2str(S1),'-', num2str(S2),'.txt'];
ffid = fopen(name,'at');
fprintf(ffid, '****************************\n %s\n', datestr(now));
fprintf(ffid, 'dim = %d, \t kernel = %s \n******************************\n', options.k,options.ker);
fprintf(ffid, 'weight = %.2f \n******************************\n', options.weight);
fprintf(ffid, 'S1 = %.2f \t S2 = %.2f \t Sf = %.2f \n******************************\n', S1,S2,Sf);

results = [];
for zzz = 1:2
for iData = 1:12
    src = char(srcStr{iData});
    tgt = char(tgtStr{iData});
    options.data = strcat(src,'-vs-',tgt);
    fprintf('Data=%s \n',options.data);
    [CXs,CXt,CYs,CYt] = prepareoffice(src,tgt,type);

    options2.xt = CXt;
    options2.yt = CYt;
    options2.xs = CXs;
    options2.ys = CYs;
      
    for iiter = 1:K
        sf = rand(size(CXs,1),1) < Sf;
        s1 = rand(length(CYs),1) < S1;
        options.xs = CXs(sf,s1);
        options.ys = CYs(s1);
        Sub{iiter} = s1;
        s2 = rand(length(CYt),1) < S2;
        options.xt = CXt(sf,s2);
        options.yt = CYt(s2);
        [temp1, temp2, pf] = ours(options);
        ttp = zeros(size(CXs,1),size(pf,2));
        ttp(sf,:) = pf;
        A{iiter} = ttp; % d*subd
    end

    % fuse K sub-projection
    iacc = fuse(options2, A);
    fprintf(ffid,'Feature-level SVM Classifier Acc = %0.2f\n', 100*iacc(1));
    fprintf(ffid,'Feature-level 1-NN Classifier Acc = %0.2f\n', 100*iacc(2));
    fprintf(ffid,'Majority Vote of 1-NN Classifier Acc = %0.2f\n', 100*iacc(3));
    fprintf(ffid,'Majority Vote of SVM Classifier Acc = %0.2f\n', 100*iacc(4));
    fprintf(ffid,'Weighted NN Acc = %0.2f\n', 100*iacc(5));
    results = [results;iacc];
    fprintf(ffid,'***************************\n%s : \n mean accuracy: \n',options.data);
    fprintf(ffid,'%.2f\n', acc);
    
    fprintf(ffid,'\n\n\n$$$$$$$$$$$$$$$$$$$$\n$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n');
end
end
fclose(ffid);