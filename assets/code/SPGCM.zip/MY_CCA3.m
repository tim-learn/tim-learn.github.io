function [Wx, D, C_diag] = MY_CCA3(X, T, Y)
T = full(T);
XX = [X,T,Y];
index = [ones(size(X,2),1);ones(size(T,2),1)*2;ones(size(Y,2),1)*3];
[V,D,C_diag] = MultiviewCCA1(XX, index, 1e-8);
Wx = V;

function [V, D ,C_diag] = MultiviewCCA1(X, index, reg)
% implements the multiview CCA method from F. Bach and M. I. Jordan.
% written by Yunchao Gong
% Y. Gong, Q. Ke, M. Isard, S. Lazebnik.  A Multi-View Embedding Space for Internet Images, Tags, and Their Semantics.
% Microsoft Research Technical Report (MSR-TR-2012-125). Under review: International Journal of Computer Vision

% X is the n*(d1+d2+...+dk) feature matrix
% X = [X1,X2,X3,...,Xk]
% index is the index of different feature views [1,1,1,2,2,2,2,3,3,3,3...]

% some covariance matrixes
C_all = cov(X);
C_diag = zeros(size(C_all));
% disp('done covariance matrix 1');
for i=1:max(index)
    index_f = find(index==i);
    % also add regularization here
    C_diag(index_f,index_f) = C_all(index_f,index_f) + reg*eye(length(index_f),length(index_f));
    C_all(index_f,index_f) = C_all(index_f,index_f) + reg*eye(length(index_f),length(index_f));
end

t1 = 0.01; 
index_1 = find(index==1);
index_2 = find(index==2);
index_3 = find(index==3);
C_all(index_1,index_2) = t1*C_all(index_1,index_2);
C_all(index_2,index_1) = t1*C_all(index_2,index_1);

% t2 = 100; 
% C_all(index_2,index_3) = t2*C_all(index_2,index_3);
% C_all(index_1,index_3) = t2*C_all(index_1,index_3);
% C_all(index_3,index_2) = t2*C_all(index_3,index_2);
% C_all(index_3,index_1) = t2*C_all(index_3,index_1);

% solve generalized eigenvalue problem
[V,D] = eig(double(C_all),double(C_diag));

% disp('done eigen decomposition');
[a, index] = sort(diag(D),'descend');
D = diag(a);
V = V(:,index);