clear all;
clc;
disp ('loading...')
load('voc_pca.mat');
ii = 100; tt = 100; %%% parameter tuning
I_tr = I_tr(:,1:ii); T_tr = T_tr(:,1:tt);
I_te = I_te(:,1:ii); T_te = T_te(:,1:tt);

comDim = 15;  %%% parameter tuning
K = length(unique(trY));

% centering
[I_tr, imean] = center_Data( I_tr );
[inum, ~] = size(I_te);
I_te = I_te - repmat(imean, inum, 1);
[T_tr, tmean] = center_Data( T_tr );
[tnum, ~] = size(T_te);
T_te = T_te - repmat(tmean, tnum, 1);

X1 = I_tr;
X2 = T_tr;

%% training
iter = 1;
max_iter = 10;
index1 = size(I_tr,2);
index2 = size(T_tr,2);

idx = kmeans(X2,K,'Replicates',5,'Distance','cosine'); % try larger replicate like 20
disp('init using text clustering')

while iter < max_iter
    fprintf('iter %d...\n',iter);
    % update W
    oidx = idx;
    Y = SY2MY(idx);
    Y(Y<0)=0;
    % normalize
    Y = Y*(diag(1./(eps+sqrt(diag(Y'*Y)))));
    diag(Y'*Y);
    
    [W,D,C_diag] = MY_CCA3(X1, X2, Y);
    S = W(:,1:comDim)'*C_diag*W(:,1:comDim);
    W1 = real(W(1:index1,1:comDim));
    W2 = real(W(index1+1:index1+index2,1:comDim));
    W3 = W(index1+index2+1:end,1:comDim); 
    
    J = X1*W1 + X2*W2;
    J = J*inv(S)*W3';
    F = Y;
    E = Y>0;
    
    max_niter = 4;
    niter = 1;
    beta = 0.01; % for voc_pca 1e-3
    while niter < max_niter
        [u,~,v] = svd(J+beta*E,'econ');
        F = u*v';
        E = F>0;
        niter = niter + 1;
    end
    [~,idx] = max(F,[],2);
       
    p=4;
    D = D.^p;
    W = real(W*D);
    W1 = W(1:index1,:);
    W2 = W(index1+1:index1+index2,:);
    W3 = W(index1+index2+1:end,:);

    fprintf('\n')
    iter = iter + 1;
    acc = accuracy(oidx,idx)/100;  
    if acc > 0.99
        break;
    end
    
end

% evalute
NI_te = I_te*W1(:,1:comDim);
NT_te = T_te*W2(:,1:comDim);
mapI = evaluate(NI_te,NT_te,teY,'cosine');
mapT = evaluate(NT_te,NI_te,teY,'cosine');
fprintf('mapI:%.4f,mapT:%.4f,average map:%.4f...\n',mapI,mapT,(mapI+mapT)/2);
