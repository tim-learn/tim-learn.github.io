function PRresult = calculatePS( queryset, test_Y,Dist )

    %%%%%%%
    Precision = [];
    Recall = [];

    maxReturnedNum = min(1000,size(Dist,2));
    gap = min(50,fix(maxReturnedNum/20));
    NumofBin = fix((maxReturnedNum)/gap);
    
    numofclass = size(unique(test_Y),1);
    Numofrelevant = zeros(1, numofclass);
    for i=1: numofclass
        index = find(test_Y == i);
        Numofrelevant(i) = length(index);
    end
    
    %Dist = EuDist2(queryset, targetset);
    %Dist = CosineDist(queryset, targetset);
    [~,index] = sort(Dist, 2, 'ascend');
    classIndex = test_Y(index);
    
    %AP = [];
    
    [num,~] = size( queryset );
%     [numoftarget,~]= size( targetset );
    for k = 1:num
        reClassIndex = find(classIndex(k, :) == test_Y(k));
        relength = length(reClassIndex);
        counts = [1:relength];
        %precision = counts./reClassIndex;
        %recall = counts/Numofrelevant(test_Y(k));
        
        
        precisionOfGap = zeros(1, NumofBin);
        recallOfGap = zeros(1, NumofBin);
        ind = 0;
        for j = gap:gap:maxReturnedNum
            ind = ind + 1;
            precisionOfGap(ind) = length(find(reClassIndex <= j)) / j;
            recallOfGap(ind) = length(find(reClassIndex <= j)) / Numofrelevant(test_Y(k));
        end
%         precisionOfGap = [precisionOfGap length(reClassIndex)/numoftarget ];
%         recallOfGap = [recallOfGap 1];
        Precision = [Precision; precisionOfGap];
        Recall = [Recall; recallOfGap];
        %AP =[AP sum(counts./reClassIndex)/relength];
    end
    
    Precision = mean(Precision);
    Recall = mean(Recall);
    Topk = gap:gap:maxReturnedNum;
    
    PRresult = zeros(size(Recall, 2),3);
    PRresult(:,1) = Recall;
    PRresult(:,2) = Precision;
    PRresult(:,3) = Topk;

end