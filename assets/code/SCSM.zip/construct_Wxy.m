function Wxy  = construct_Wxy( Label_view1, Label_view2 )

%% ***************************************************************
%Label_view1    num1*c
%Label_view2    num2*c
%% ***********************************************************

% [num_sample1 c] = size(Label_view1);
% [num_sample2 c] = size(Label_view2);
% if num_sample1 ~= num_sample2
%     error('The number of samples from one view is not identical to that from another view.');
% end
% temp1 = repmat(Label_view1, 1, num_sample2);
% temp2 = repmat(Label_view2', num_sample1, 1);
% Wxy = temp1 == temp2;

Wxy = Label_view1 * Label_view2';
Wxy(find(Wxy))=1;

end

