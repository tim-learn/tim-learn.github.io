function L = construct_L( X_multiview, Label, alpha, beta )

%% ***************** W=[W_11 W_12;W_21 W_22]**********************
num_view = size(X_multiview,2);
Num_sample = zeros(num_view, 1);
for i=1:num_view
    Num_sample(i) = size(X_multiview{i},1);
end
W = zeros(sum(Num_sample), sum(Num_sample));

for i = 1:num_view
    %Label_i = Label_multiview{i};
    Label_i = Label;
    
    for j = 1:num_view
         rs = sum(Num_sample(1:i-1))+1;
         re = sum(Num_sample(1:i));
         cs = sum(Num_sample(1:j-1))+1;
         ce = sum(Num_sample(1:j));       
        if i == j
            %options.gnd = Label_i;
            options.Metric = 'Euclidean';
            %options.Metric = 'Cosine';
            %options.NeighborMode = 'Supervised';
            options.NeighborMode = 'KNN';
            options.k = 100;
            %options.WeightMode = 'Binary';
            options.WeightMode =  'HeatKernel';
            options.t = 1;
            X_i = X_multiview{i};
            W(rs:re,cs:ce) = constructW(X_i, options) * beta;
        else
            %Label_j = Label_multiview{j};
            Label_j = Label;
            W(rs:re,cs:ce) = construct_Wxy(Label_i, Label_j) * alpha;
            %W(rs:re,cs:ce) = eye(re-rs+1, ce-cs+1);
        end           
    end
end
W = (W+W')/2;
D = diag(sum(W,2));
L = D - W;
end

