function Y = calculate_Y(U_a, X_a, V, U_b, X_b, Y, lambda1)
	t = sum(V);
	A = U_a' * X_a * V * V';
	B = U_b' * X_b * V * V';
	C = U_a' * X_a;
	D = U_b' * X_b;
	n = size(V,1);
	row = size(C,1);
	for i = 1:n
		if t(i) == 1
			Y(:,i) = zeros(row,1);
			a = A(:,i);
			b = B(:,i);
			c = C(:,i);
			d = D(:,i);
			v = V(:,i);
			fr = i-1;
			be = i+1;
			A_1 = [A(:,1:fr) A(:,be:n)];
			B_1 = [B(:,1:fr) B(:,be:n)];
			C_1 = [C(:,1:fr) C(:,be:n)];
			D_1 = [D(:,1:fr) D(:,be:n)];
			V_1 = [V(:,1:fr) V(:,be:n)];
			Y_1 = [Y(:,1:fr) Y(:,be:n)];

			new_mtx = -a - b + 2 * Y_1 * V_1' * v + lambda1 * Y_1 * D_1' * c + lambda1 * Y_1 * C_1' * d;

			[~,index] = min(new_mtx);
			Y(index, i) = 1;
		end
	end
end