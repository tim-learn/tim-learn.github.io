%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If you use this code, please cite the following paper:
% Jian Liang, Zhihang Li, Dong Cao, Ran He and Jingdong Wang, "Self-Paced Cross-Modal Subspace Matching," 
% In ACM SIGIR conference on Research and Development in Information Retrieval (SIGIR), pp. 569-578. ACM, 2016.
% Contact: jian.liang@nlpr.ia.ac.cn
% the dataset used in SIGIR2016 can be downloaded from http://jian-liang.github.io/home/user/Publications.html
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function demo(data)
	disp('SCSM');
	%% load data
    load('wiki');
    class_num = length(unique(trY));
    Y_tr = kmeans(T_tr, class_num,'distance','cosine','emptyaction','singleton','replicate',5);
	Y = SY2MY(Y_tr);

	%% training
	% note that these parameters need to be tuned for different datasets
	disp('training...');
	Param.lambda1 = 1e-3;
	Param.lambda2 = 1e-2;
	Param.k = 0.92;
	Param.alpha = 1;
	Param.beta = 1;

	Param.niter = 5;
	[map W_i W_t obj] = SCSM( I_tr', T_tr', trY, Y', I_te', T_te', teY, Param );

	%% testing
	disp('testing...');

    Image_te = W_i' * I_te';
    Text_te  = W_t' * T_te';

	Wtrue = teY;

	dis_type = 'cosine';
	[imap, iPR, iPS, iMAPperClass] = evaluate( Image_te', Text_te', Wtrue, dis_type);
	str = sprintf( 'The MAP of image as query is %f%%\n', imap *100 );
	disp(str);

	[tmap, tPR, tPS, tMAPperClass] = evaluate( Text_te', Image_te', Wtrue, dis_type);
	str = sprintf( 'The MAP of text as query is %f%%\n', tmap *100 );
	disp(str);
	disp((imap+tmap)*100/2); 
end