function [map, PR, PS, MAPperClass] = evaluate(Query, Base, Wtrue, distype)
if nargin<3
    disp('missing arguments...')
    return
end
if nargin < 4
    distype = 'cosine';
end

switch distype
    case 'eudist'
        Dist = EuDist2(Query, Base);
    case 'cosine'
        Dist = CosineDist(Query, Base);
    case 'ip'
        Dist = -Query*Base';
    case 'hel'
        Dist = -sqrt(Query)*sqrt(Base)';
    case 'p2'
        Dist = -(Query.^2)*sqrt(Base.^2)';
    case 'min-max'
        Dist = zeros(size(Query,1),size(Base,1));
        for k = 1:size(Query,1)
            for kk = 1:size(Base,1)
                Dist(k,kk) = -sum(min(Query(k,:),Base(kk,:)))/sum(max(Query(k,:),Base(kk,:)));
            end
        end
        
end

[map MAPperClass] = calculateMAP( Query, Wtrue, Dist);
if nargout == 1
    return;
end
% PR = 0;PS = 0;return
PR = calculatePR(Query, Wtrue, Dist);
% PS = 0;
PS = calculatePS(Query, Wtrue, Dist);
% plot(PR(:,1),PR(:,2),'--r+');
% plot(PS(:,3),PS(:,2),'r*-')
end
