


% X_i : di * n     X_t : dt * n
% W_i : di * c     W_t : dt * c
% U_i : c  * k     U_t : c  * k
% D_i : n  * n     D_t : n  * n
% V   : k  * n

function [map W_i W_t obj] = SCSM(X_i, X_t, trY, Y, I_te, T_te, teY, Param)

    % step 1:initialize V using kmeans
    disp ('step 1:initialize Y using kmeans');
%    class_num = 20;
%    my_Y_tr = kmeans(X_t', class_num, 'emptyaction','singleton','replicate',5);
%   my_Y_tr = tr_Y;
%   Y = (SY2MY(Y))';

    % step 2:calcualte L
    disp ('step 2:calcualte L');
    alpha = Param.alpha;
    beta = Param.beta;
    Data_multimodal = cell(1,2);
    Data_multimodal{1} = X_i';
    Data_multimodal{2} = X_t';
    L = construct_L( Data_multimodal, Y', alpha, beta );

    i_num_sample = size(X_i', 1);
    t_num_sample = size(X_t', 1);
    L_i = L(             1:i_num_sample,                           1:i_num_sample);
    L_t = L(i_num_sample+1:i_num_sample+t_num_sample, i_num_sample+1:i_num_sample+t_num_sample);
    L_it = L(            1:i_num_sample, i_num_sample+1:i_num_sample+t_num_sample);

    % step 3:calcuate W_i,W_t  
    c = size(Y, 1);
    di = size(X_i, 1);
    dt = size(X_t, 1);

    W_i = eye(di, c);
    W_t = eye(dt, c);

    % iteration:
    disp ('iteration');
    lambda1 = Param.lambda1;
    lambda2 = Param.lambda2;
    k = Param.k;
    niter = Param.niter;

    roc = zeros(niter, 9);

    for i = 1:niter
        % update w
        loss = W_i'*X_i - Y;
        loss = sqrt(sum(loss .^ 2));
        w = calculate_w(loss, k);
        ratio = sum(w)/length(w);
        w = diag(w);

        % the objective function value
        Wi_Xi = W_i' * X_i;
        Wt_Xt = W_t' * X_t;

        loss_i = (Wi_Xi - Y);
        term1 = trace(loss_i * loss_i');      

        loss_t = (Wt_Xt - Y);
        term2 = trace(loss_t * loss_t');

        term3 = lambda1 * trace(Wi_Xi * L_i * Wi_Xi');
        term4 = lambda1 * trace(Wt_Xt * L_t * Wt_Xt');

        term5 = 2 * lambda1 * trace(Wi_Xi * L_it * Wt_Xt');

        term6 = lambda2 * trace(W_i * W_i');
        term7 = lambda2 * trace(W_t * W_t');

        term8 = sum(sum(w));

        % obj(i) = term1 + term2 + term3 + term4 + term5 + term6 + term7 + term8;
        obj(i) = term1 + term2 + term3 + term4 + term5;
        roc(i, 1) = term1;
        roc(i, 2) = term2;
        roc(i, 3) = term3;
        roc(i, 4) = term4;
        roc(i, 5) = term5;
        roc(i, 6) = term6;
        roc(i, 7) = term7;
        roc(i, 8) = term8;
        roc(i, 9) = obj(i);



        % update W_i,W_t
        Wi_left_co     = (X_i * w * w' * X_i') + (lambda1 * X_i * L_i * X_i') + (lambda2 * eye(size(X_i,1), size(X_i,1)));
        Wi_right_value = (X_i * w * w' * Y') - (lambda1 * X_i * L_it * X_t' * W_t);
        W_i = Wi_left_co \ Wi_right_value;

        Wt_left_co     = (X_t * w * w' * X_t') + (lambda1 * X_t * L_t * X_t') + (lambda2 * eye(size(X_t,1), size(X_t,1)));
        Wt_right_value = (X_t * w * w' * Y') - (lambda1 * X_t * L_it * X_i' * W_i);
        W_t = Wt_left_co \ Wt_right_value;

        % update Y
%         Y_left_co = 2 * w * w' - lambda1 * X_t' * W_t * W_i' * X_i - lambda1 * X_i' * W_i * W_t' * X_t;
%         Y_right_co =  W_i' * X_i * w * w' + W_t' * X_t * w * w';
%         
%         temp_Y = Y_right_co * pinv(Y_left_co);
% 
%         [~,index] = max(temp_Y);
%         Y = zeros(size(temp_Y));
%         for j = 1:size(temp_Y, 2)
%             Y(index(j), j) = 1;
%         end
        Y = calculate_Y(W_i, X_i, w, W_t, X_t, Y, lambda1);
        
        temp_L_it = Y' * Y;
        L_it = zeros(size(temp_L_it)) - temp_L_it;
        

        disp(['------------------------' num2str(i) '------------------------']);
        disp(ratio);
        Image_te = W_i' * I_te;
        Text_te  = W_t' * T_te;
        % Image_tr = W_i' * X_i;
        % Text_tr  = W_t' * X_t;
        Wtrue = teY;
        dis_type = 'cosine';
        imap = evaluate( Image_te', Text_te', Wtrue, dis_type);
        str = sprintf( 'The MAP of image as query is %f\n', imap);
        disp(str);

        tmap = evaluate( Text_te', Image_te', Wtrue, dis_type);
        str = sprintf( 'The MAP of text as query is %f\n', tmap);
        disp(str);
        map = (imap+tmap)/2
    end
end