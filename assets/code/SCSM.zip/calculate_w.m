function w = calculate_w(loss, k)
	loss_size = size(loss);
	k_ext = repmat(1/k, loss_size);
	dif = loss - k_ext;

	w = ones(loss_size);
	[r,c] = find(dif > 0);

	for i = 1:length(r)
		w(r(i), c(i)) = 0;
	end
end